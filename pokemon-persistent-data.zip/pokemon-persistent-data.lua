local plugin = {}

plugin.name = "Persistent Pokemon Shuffler Data"
plugin.author = "JeffIsFine"

plugin.settings = {
	-- Flags for what to share between games in shuffle
	 {name='party', type='boolean', label='Synchronize Party (WITHIN GEN ONLY)'}
	,{name='pcpkmn', type='boolean', label='Synchronize PC PKMN Boxes (SLOW)'}
	,{name='pokedex', type='boolean', label='Synchronize Pokedex'}
	,{name='money', type='boolean', label='Synchronize Money'}
	,{name='items', type='boolean', label='Synchronize Items'}
	,{name='events', type='boolean', label='Synchronize Event Flags and Trainers (UNSTABLE, WITHIN GEN ONLY)'}
	,{name='prevbattleswitch', type='boolean', label='Prevent Shuffle in Battle (BUGGY IF OFF)'}
--	,{name='persist_after_new_game', type='boolean', label='Preserve Data after New Game'}
--	,{name='trainers', type='boolean', label='Synchronize Defeated Non-Leader Trainers'}
--	,{name='leaders', type'boolean', label='Synchronize Defeated Leaders'}
}

plugin.description =
[[
	Persists specified data between shuffled games. Certain limitations apply, particularly between different gens. Those will be specified in each setting's name.
]]

-- Static Memory Locations of information
-- Offsets included in Gen 3+, which utilizes Dynamic Memory Allocation
local gamedata = {
	["pkmnrdbleng"]={ -- Pokemon - Red/Blue Version -  (USA, Europe) (SGB Enhanced).gb
		gen = 1
		,inbattle_addr = 0xd057
		,party_addr = 0xD163 -- Party count is first byte
		,party_count_addr = 0xD163
		,party_bytes = 404
		,pokedex_addr = 0xD2F7
		,pokedex_bytes = 38
		,item_pocket_addr = 0xD31D
		,item_pocket_bytes = 42
		,money_addr = 0xD347
		,money_bytes = 3
		,pc_item_addr = 0xD53A
		,pc_item_bytes = 102
		,flags_addr = 0xD5A6
		,flags_bytes = 698
		,pc_pokemon_addr = 0xDA80
		,pc_pokemon_bytes = 1122
	},
	["pkmnyeleng"]={ -- Pokemon - Yellow Version -  Special Pikachu Edition (USA, Europe) (CGB+SGB Enhanced).gb
		gen = 1
		,inbattle_addr = 0xd056
		,party_addr = 0xD162 -- Party count is first byte
		,party_count_addr = 0xD162
		,party_bytes = 404
		,pokedex_addr = 0xD2F6
		,pokedex_bytes = 38
		,item_pocket_addr = 0xD31C
		,item_pocket_bytes = 42
		,money_addr = 0xD346
		,money_bytes = 3
		,pc_item_addr = 0xD539
		,pc_item_bytes = 102
		,flags_addr = 0xD5A5
		,flags_bytes = 698
		,pc_pokemon_addr = 0xDA7F
		,pc_pokemon_bytes = 1122
	},
	["pkmngolsileng"]={ -- Pokemon - Gold/Silver Version (USA, Europe) (SGB Enhanced) (GB Compatible).gbc
		gen = 2
		,inbattle_addr = 0xc05a -- Not exact variable; 1 in battle except after defeat determined, and 0 all other times
		,party_addr = 0xDA22 -- Party count is first byte
		,party_count_addr = 0xDA22
		,party_bytes = 428
		,pokedex_addr = 0xDBE4
		,pokedex_bytes = 64
		,item_pocket_addr = 0xD57E 
		,item_pocket_bytes = 152
		,money_addr = 0xD573
		,money_bytes = 3
		,pc_item_addr = 0xD616
		,pc_item_bytes = 102
		,flags_addr = 0xD7B7
		,flags_bytes = 256
		,pc_pokemon_addr = 0xAD6C
		,pc_pokemon_bytes = 1102
	},
	["pkmncryeng"]={ -- Pokemon - Crystal Version (USA, Europe) (Rev 1).gbc
		gen = 2
		,inbattle_addr = 0xC15A -- Not exact variable; 1 in battle except after defeat determined, and 0 all other times
		,party_addr = 0xDCD7 -- Party count is first byte
		,party_count_addr = 0xDCD7
		,party_bytes = 428
		,pokedex_addr = 0xDE99
		,pokedex_bytes = 64
		,item_pocket_addr = 0xD859 
		,item_pocket_bytes = 152
		,money_addr = 0xD84E
		,money_bytes = 3
		,pc_item_addr = 0xD8F1
		,pc_item_bytes = 102
		,flags_addr = 0xDA72
		,flags_bytes = 256
		,pc_pokemon_addr = 0xad10
		,pc_pokemon_bytes = 1102
	},
	["pkmnfrlgeng"]={ -- FireRed/LeafGreen Version (USA, Europe) (Rev 1).gba
		gen = 3
		,inbattle_addr = 0x03003529
		,party_count_addr = 0x02024029
		,party_addr = 0x02024284
		,party_bytes = 600
		
		,save_block_1_pntr = 0x03005008
		,seen1_offset = 0x05F8
		,seen2_offset = 0x3A18
		,money_offset = 0x0290
		,money_bytes = 4
		,pc_item_offset = 0x0298
		,pc_item_bytes = 120
		,item_pocket_offset = 0x0310
		,item_pocket_bytes = 744
		,flags_offset = 0x0EE0
		,flags_bytes = 800
		
		,save_block_2_pntr = 0x0300500C
		,xor_key_offset = 0x0F20
		,pokedex_offset = 0x018
		,pokedex_bytes = 120
		,pokedex_seen_offset = 0x44
		,pokedex_seen_bytes = 52
		
		,save_block_3_pntr = 0x03005010
		,pc_pokemon_bytes = 33744
	},
	["pkmnrusaeng"]={ -- Ruby/Sapphire Version (USA, Europe) (Rev 1).gba
		gen = 3
		,inbattle_addr = 0x300352D
		,party_count_addr = 0x03004350
		,party_addr = 0x03004360
		,party_bytes = 600
	
		,save_block_1_pntr = 0x02025734
		,seen1_offset = 0x938
		,seen2_offset = 0x3A8C
		,money_offset = 0x490
		,money_bytes = 4
		,pc_item_offset = 0x498
		,pc_item_bytes = 200
		,item_pocket_offset = 0x560
		,item_pocket_bytes = 744
		,flags_offset = 0x1220
		,flags_bytes = 812

		,save_block_2_pntr = 0x02024EA4
		,pokedex_offset = 0x018
		,pokedex_bytes = 120
		,pokedex_seen_offset = 0x44
		,pokedex_seen_bytes = 52
		
		,save_block_3_pntr = 0x020300a0
		,pc_pokemon_bytes = 33744		
	},
	["pkmnemeng"]={ -- Pokemon - Emerald Version (USA, Europe).gba
		gen = 3
		,inbattle_addr = 0x30026F9
		,part_count_addr = 0x020244e9
		,party_addr = 0x020244EC
		,party_bytes = 600
		
		,save_block_1_pntr = 0x02024a54
		,seen1_offset = 0x988
		,seen2_offset = 0x3B24
		,money_offset = 0x490
		,money_bytes = 4
		,pc_item_offset = 0x498
		,pc_item_bytes = 200
		,item_pocket_offset = 0x560
		,item_pocket_bytes = 744
		,flags_offset = 0x1270
		,flags_bytes = 812
		
		,save_block_2_pntr = 0x02025a00
		,pokedex_offset = 0x018
		,pokedex_bytes = 120
		,pokedex_seen_offset = 0x44
		,pokedex_seen_bytes = 52
		
		,save_block_3_pntr = 0x02029808
		,pc_pokemon_bytes = 33744
	}
}
-- Empty variables to be set during save and load of each game

-- Other Plugin-specific variables
local freeze_frame = false
local battle_frame_start

-- Return name of ROM in prep for gathering static information
local function get_game_tag()
	-- try to just match the rom hash first
	local tag = get_tag_from_hash_db(gameinfo.getromhash(), 'plugins/pokemon-hashes.dat')
	if tag ~= nil and gamedata[tag] ~= nil then return tag end

	-- check to see if any of the rom name samples match
	local name = gameinfo.getromname()
	for _,check in pairs(backupchecks) do
		if check.test() then return check.tag end
	end

	return nil
end

-- Get hex addresses for values that utilize DMA save blocks (gen 3 and higher)
local function getSaveBlockAddress(pntr, offset)
	if not pntr or not offset then return nil end
	return memory.read_u32_le(pntr) + offset
end

-- Creates table of RAM addresses. Differentiates between pre-saveblock gens and post-saveblock gens (Gen 3 onward).
--[[local function setAddrs(metadata)
	local addrs = {
		inbattle = metadata.inbattle_addr
		,party = metadata.party_addr
		,pcpkmn = metadata.pc_pokemon_addr or memory.read_u32_le(metadata.save_block_3_pntr)
		,pokedex = metadata.pokedex_addr or getSaveBlockAddress(metadata.save_block_2_pntr, metadata.pokedex_offset)
		,seen1 = getSaveBlockAddress(metadata.save_block_1_pntr, metadata.seen1_offset)
		,seen2 = getSaveBlockAddress(metadata.save_block_1_pntr, metadata.seen2_offset)
		,pokedex_seen = getSaveBlockAddress(metadata.save_block_2_pntr, metadata.pokedex_seen_offset)
		,money = metadata.money_addr or getSaveBlockAddress(metadata.save_block_1_pntr, metadata.money_offset)
		,pocket_items = metadata.item_pocket_addr or getSaveBlockAddress(metadata.save_block_1_pntr, metadata.item_pocket_offset)
		,pc_items = metadata.pc_item_addr or getSaveBlockAddress(metadata.save_block_1_pntr, metadata.pc_item_offset)
		,events = metadata.flags_addr or getSaveBlockAddress(metadata.save_block_1_pntr, metadata.flags_offset)
	}
	
	return addrs
end--]]

--[[-- Set 32-bit XOR Key from Save Block 2
function setXorKey32(save_block_2_addr, xor_key_offset)
	return memory.read_u32_le(save_block_2_addr + xor_key_offset)
end--]]

-- XOR Pocket Items
function xorPocketItems(xor_key_addr, pocket_items)
	local save_block_2_xor_key_first_byte = memory.read_u8(xor_key_addr)		-- Needed for XOR'ing on 1, 2, and 4 byte values
	local save_block_2_xor_key_second_byte = memory.read_u8(xor_key_addr + 1)

 	for k, v in ipairs(pocket_items) do
        if k % 4 == 3 then
				pocket_items[k] = bit.bxor(v, save_block_2_xor_key_first_byte)
        elseif k % 4 == 0 then
                pocket_items[k] = bit.bxor(v, save_block_2_xor_key_second_byte)
        end
	end
	return pocket_items
end

-- Capture all enabled persistent RAM states
function getRAMStates(data, settings)
	if settings.party then 
		data.prevvalues.party_count, data.prevvalues.party_values = 
			getParty(
				data.metadata.party_count_addr
				,data.metadata.party_addr
				,data.metadata.party_bytes
			) 
	end
	
	if settings.pcpkmn then 
		data.prevvalues.pc_pokemon_values = 
			getPCPkmn(
				data.metadata.pc_item_addr or memory.read_u32_le(data.metadata.save_block_3_pntr)
				,data.metadata.pc_pokemon_bytes
			) 
	end
	
	if settings.pokedex then 
		data.prevvalues.pokedex_values, data.prevvalues.pokedex_seen_values = 
			getPokedex(
				data.metadata.pokedex_addr or getSaveBlockAddress(data.metadata.save_block_2_pntr, data.metadata.pokedex_offset)
				,getSaveBlockAddress(data.metadata.save_block_2_pntr, data.metadata.pokedex_seen_offset)
				,data.metadata.pokedex_bytes
				,data.metadata.pokedex_seen_bytes
			) 
	end
	
	if settings.money then 
		data.prevvalues.money_decoded_value = 
			getMoney(
				data.metadata.money_addr or getSaveBlockAddress(data.metadata.save_block_1_pntr, data.metadata.money_offset)
				,getSaveBlockAddress(data.metadata.save_block_2_pntr, data.metadata.xor_key_offset)
			)
	end
	
	if settings.items then 
		data.prevvalues.pc_items, data.prevvalues.pocket_items = 
			getItems(
				data.metadata.pc_item_addr or getSaveBlockAddress(data.metadata.save_block_1_pntr, data.metadata.pc_item_offset)
				,data.metadata.item_pocket_addr or getSaveBlockAddress(data.metadata.save_block_1_pntr, data.metadata.item_pocket_offset)
				,getSaveBlockAddress(data.metadata.save_block_2_pntr, data.metadata.xor_key_offset)
				,data.metadata.pc_item_bytes
				,data.metadata.item_pocket_bytes
			) 
	end
	
	if settings.events then 
		data.prevvalues.flags_values = 
			getEvents(
				data.metadata.flags_addr or getSaveBlockAddress(data.metadata.save_block_1_pntr, data.metadata.flags_offset)
				,data.metadata.flags_bytes
			) 
	end	
end

-- Capture current party
function getParty(party_count_addr, party_addr, party_bytes)
	return memory.read_u8(party_count_addr), memory.read_bytes_as_array(party_addr, party_bytes)
end

-- Capture PC state
function getPCPkmn(pc_pokemon_addr, pc_pokemon_bytes)
	return memory.read_bytes_as_array(pc_pokemon_addr, pc_pokemon_bytes)
end

-- Capture Pokedex state; cature seen flags state separately to make it easier to overwrite seen flags in SaveBlock1
function getPokedex(pokedex_addr, pokedex_seen_addr, pokedex_bytes, pokedex_seen_bytes)
	pokedex_values = memory.read_bytes_as_array(pokedex_addr, pokedex_bytes)

	-- Return nil for pokemon seen flags; don't need separate seen flags variable for cross-check addresses 
	if not pokedex_seen_addr then
		pokedex_seen_values = nil
	else
		pokedex_seen_values = memory.read_bytes_as_array(pokedex_seen_addr, pokedex_seen_bytes)
	end
	
	return pokedex_values, pokedex_seen_values
end

-- Capture Money
function getMoney(money_addr, xor_key_addr)
	-- Decoding money value only necessary in gens > 2
	if not xor_key_addr then
		return memory.read_u32_le(money_addr)
	else
		local money_encoded_value = memory.read_u32_le(money_addr)
		local save_block_2_xor_key_32 = memory.read_u32_le(xor_key_addr)
		return bit.bxor(money_encoded_value, save_block_2_xor_key_32)
	end
end

-- Capture PC and Bag Items
function getItems(pc_item_addr, item_pocket_addr, xor_key_addr, pc_item_bytes, item_pocket_bytes)
	-- PC Items
	local pc_items = memory.read_bytes_as_array(pc_item_addr, pc_item_bytes)
	
	-- Bag items (all pockets)
	local pocket_items = memory.read_bytes_as_array(item_pocket_addr, item_pocket_bytes)	
	
	-- Encoding only necessary in gens > 2
	if not xor_key_addr then
		return pc_items, pocket_items
	else
		local pocket_items_encoded = xorPocketItems(xor_key_addr, pocket_items)
		return pc_items, pocket_items_encoded
	end
end

-- Capture Event Flags
function getEvents(flags_addr, flags_bytes)
	flags_values = memory.read_bytes_as_array(flags_addr, flags_bytes)	
	return flags_values
end

-- Capture Trainer Flags *** Under Construction ***
function getTrainers()
	local trainers_addr = save_block_1_addr + data.flags_offset + 0x500
	flags_values = memory.read_bytes_as_array(flags_addr, 288)	
end

-- Set all enabled persistent RAM states
function setRAMStates(currgen_data, prevgen_prevvalues, settings)
	-- Don't bother setting RAM if RAM has just initialized (~12 frames per game); gen > 2
	if currgen_data.metadata.gen >= 3 then
		local save_block_2_addr = memory.read_u32_le(currgen_data.metadata.save_block_2_pntr)
		if save_block_2_addr == 0 then
			return
		end
	end

	if settings.party then 
		setParty(
			currgen_data.metadata.gen
			,prevgen_prevvalues.gen
			,currgen_data.metadata.party_count_addr
			,currgen_data.prevvalues.party_count
			,currgen_data.metadata.party_addr
			,currgen_data.prevvalues.party_values
		)
	end
	
	if settings.pcpkmn then 
		setPCPkmn(
			currgen_data.metadata.gen
			,prevgen_prevvalues.gen
			,currgen_data.metadata.pc_item_addr or memory.read_u32_le(currgen_data.metadata.save_block_3_pntr)
			,currgen_data.prevvalues.pc_pokemon_values
		) 
	end
	
	if settings.pokedex then 
		setPokedex(
			currgen_data.metadata.gen
			,prevgen_prevvalues.gen
			,currgen_data.metadata.pokedex_addr or getSaveBlockAddress(currgen_data.metadata.save_block_2_pntr, currgen_data.metadata.pokedex_offset)
			,getSaveBlockAddress(currgen_data.metadata.save_block_2_pntr, currgen_data.metadata.pokedex_seen_offset)
			,getSaveBlockAddress(currgen_data.metadata.save_block_1_pntr, currgen_data.metadata.seen1_offset)
			,getSaveBlockAddress(currgen_data.metadata.save_block_1_pntr, currgen_data.metadata.seen2_offset)
			,currgen_data.prevvalues.pokedex_values
			,currgen_data.prevvalues.pokedex_seen_values
		) 
	end
	
	if settings.money then 
		setMoney(
			currgen_data.metadata.money_addr or getSaveBlockAddress(currgen_data.metadata.save_block_1_pntr, currgen_data.metadata.money_offset)
			,getSaveBlockAddress(currgen_data.metadata.save_block_2_pntr, currgen_data.metadata.xor_key_offset)
			,prevgen_prevvalues.money_decoded_value
		)
	end
	
	if settings.items then 
		setItems(
			currgen_data.metadata.pc_item_addr or getSaveBlockAddress(currgen_data.metadata.save_block_1_pntr, currgen_data.metadata.pc_item_offset)
			,currgen_data.metadata.item_pocket_addr or getSaveBlockAddress(currgen_data.metadata.save_block_1_pntr, currgen_data.metadata.item_pocket_offset)
			,getSaveBlockAddress(currgen_data.metadata.save_block_2_pntr, currgen_data.metadata.xor_key_offset)
			,currgen_data.prevvalues.pc_items
			,currgen_data.prevvalues.pocket_items
		) 
		end
	
	if settings.events then 
		setEvents(
			currgen_data.metadata.flags_addr or getSaveBlockAddress(currgen_data.metadata.save_block_1_pntr, currgen_data.metadata.flags_offset)
			,currgen_data.prevvalues.flags_values
		) 
	end	
end

-- Replace current party if party table is not empty (ie. at first load of session)
function setParty(currgen, prevgen, party_count_addr, party_count, party_addr, party_values)
    --[[ Skip cross-gen pokemon transfers for now
	if currgen ~= prevgen then 
		log_message("Debug: Cross-gen party transfer skipped!\nCurrent Gen: " .. currgen .. "\nPrevious Gen: " .. prevgen)
		return 
	end --]]
	
	if next(party_values) ~= nil then
		--pc_pokemon_addr = memory.read_u32_le(save_block_3_pntr)
		memory.write_u8(party_count_addr, party_count)
		memory.write_bytes_as_array(party_addr, party_values)
	end	
end

-- Replace current PC boxes if pcs table is not empty (ie. at first load of session)
function setPCPkmn(currgen, prevgen, pc_pokemon_addr, pc_pokemon_values)
    --[[ Skip cross-gen pokemon transfers for now
	if currgen ~= prevgen then 
		log_message("Debug: Cross-gen PC Pokemon transfer skipped!")
		return 
	end --]]

	if next(pc_pokemon_values) ~= nil then
		memory.write_bytes_as_array(pc_pokemon_addr, pc_pokemon_values)
	end
end

-- Replace current Pokedex and Seen Flags if pokedex is not empty
function setPokedex(currgen, prevgen, pokedex_addr, pokedex_seen_addr, seen1_addr, seen2_addr, pokedex_values, pokedex_seen_values)
    -- Skip cross-gen pokemon transfers for now
	--[[if currgen ~= prevgen then 
		log_message("Debug: Cross-gen Pokedex transfer skipped!")
		return 
	end--]]

	if next(pokedex_values) ~= nil then
		memory.write_bytes_as_array(pokedex_addr, pokedex_values)
		
		-- Only necessary in gens > 2
		if seen1_addr then
			memory.write_bytes_as_array(pokedex_seen_addr, pokedex_seen_values)
			memory.write_bytes_as_array(seen1_addr, pokedex_seen_values)
			memory.write_bytes_as_array(seen2_addr, pokedex_seen_values)
		end
	end
end

-- Replace current money with money from previous game unless no shuffle has occurred this session or a funny value is received
function setMoney(money_addr, xor_key_addr, money_decoded_value)
	if money_decoded_value ~= nil and money_decoded_value >= 0 then
		-- Encoding money value only necessary in gens > 2
		if not xor_key_addr then
			memory.write_u32_le(money_addr, money_decoded_value)
		else
			local save_block_2_xor_key_32 = memory.read_u32_le(xor_key_addr)
			local money_reencoded_value = bit.bxor(money_decoded_value, save_block_2_xor_key_32)
			memory.write_u32_le(money_addr, money_reencoded_value)
		end
	end
end

-- Replace current PC and Bag Items with items from previous game unless no shuffle has occurred this session or a funny value is received
function setItems(pc_item_addr, item_pocket_addr, xor_key_addr, pc_items, pocket_items)
	-- PC Items
	if next(pc_items) ~= nil then
		memory.write_bytes_as_array(pc_item_addr, pc_items) 
	end 

	-- Bag items (all pockets) 
	if next(pocket_items) ~= nil then
		-- Encoding only necessary in gens > 2
		if not xor_key_addr then
			memory.write_bytes_as_array(item_pocket_addr, pocket_items)
		else
			local pocket_items_encoded = xorPocketItems(xor_key_addr, pocket_items)
			memory.write_bytes_as_array(item_pocket_addr, pocket_items_encoded)
		end
	end
end

-- Replace current event flags with items from previous game unless no shuffle has occured this session
-- Current implementation will probably introduce issues and softlocks
function setEvents(flags_addr, flags_values)
	if next(flags_values) ~= nil then
		memory.write_bytes_as_array(flags_addr, flags_values) 
	end
end

-- Prevents swapping of game during battle
function freezeBattle(inbattle_addr) 
	local inbattle_value = memory.read_u8(inbattle_addr)
	if inbattle_value ~= 0 then
		-- Za Warudo on first battle frame
		if not freeze_frame then
			battle_frame_start = config.frame_count
			freeze_frame = true
			config.frame_count = 0 -- Creates an arbitrarily large time until next check
		end
		
		-- Only update frame when close to swap time to decrease overhead
		if next_swap_time - config.frame_count <= 2 then
			config.frame_count = 0
			log_message("Continuing time stop since frames left are <=2!")
		end
		
	-- Frame count set to beginning of battle on frame battle ends
	elseif freeze_frame == true then
		config.frame_count = battle_frame_start
		freeze_frame = false 
	end
end


-- Core Bizhawk Shuffler functions
-- called once at the start
function plugin.on_setup(data, settings)
	-- Set previous session's list of games and any game-specific data that needs to be stored in a persistent table
	-- Otherwise, create blank table to gather this info anew
	data = data or {
		tags
		,prevtag
		,currtag
	}
	data.tags = data.tags or {}
	data.prevtag = data.prevtag or nil
	data.currtag = data.currtag or nil
end

-- called each time a game/state loads
function plugin.on_game_load(data, settings)
	-- Set game id in data table
	local tag = data.tags[gameinfo.getromhash()] or get_game_tag()
	data.tags[gameinfo.getromhash()] = tag or NO_MATCH
	
	-- first time through with a bad match, tag will be nil
	-- can use this to print a debug message only the first time
	if tag ~= nil and tag ~= NO_MATCH then
		log_message('game match: ' .. tag)
		--local gamemeta = gamedata[tag]
		data.currtag = tag
		data[tag] = data[tag] or {
			metadata = gamedata[tag]
			,prevvalues = {}
		}
	elseif tag == nil then
		log_message(string.format('unrecognized? %s (%s)',
			gameinfo.getromname(), gameinfo.getromhash()))
	end
	
	-- Replace RAM segments per chosen settings
	-- No need to set RAM states if there was no previous game
	-- Only use same-gen prevvalues until cross-gen compatibility
	if data[data.currtag].prevvalues and data[data.currtag].prevvalues.party_count then 
		setRAMStates(data[data.currtag], data[data.prevtag].prevvalues, settings)
	end
end

-- called each frame
function plugin.on_frame(data, settings)
    -- Check memory just initialized; takes ~12 frames; gen > 2 only
	if data[data.currtag].metadata.gen >= 3 then
		local save_block_2_addr = memory.read_u32_le(data[data.currtag].metadata.save_block_2_pntr)
		if save_block_2_addr == 0 then
			return
		end
	end

	-- Set RAM states in middle of play only if three conditions met:
		-- 1) this isn't the first game loaded for this session (so prevvalues exist),
		-- 2) the previous game had already obtained at least 1 party member,
		-- 3a) starting a new game,  
		-- 3b) loading a save file without the starter pokemon, (overwrites WRAM with SRAM data)
		-- 3c) spawning for the first time in game	(wipes WRAM data)
		-- party count = 0 in last 3 cases
	if data[data.currtag].prevvalues.party_count
	  and data[data.currtag].prevvalues.party_count ~= 0
	then
		local party_count = memory.read_u8(data[data.currtag].metadata.party_count_addr)
		if party_count == 0 then
			setRAMStates(data[data.currtag], data[data.prevtag].prevvalues, settings)
		end
	end


	-- Don't switch if in middle of battle if using that setting
	if settings.prevbattleswitch then 
		freezeBattle(data[data.currtag].metadata.inbattle_addr) 
	end 
end

-- called each time a game/state is saved (before swap)
function plugin.on_game_save(data, settings)	
	-- Capture RAM segments designated by settings on switch
	getRAMStates(data[data.currtag], settings)

	-- Track tag of outgoing game in data and gen of outgoing game in data[tag].prevvalues tables
	data.prevtag = data.currtag
	data[data.prevtag].prevvalues.gen = data[data.currtag].metadata.gen
end

-- called each time a game is marked complete
function plugin.on_complete(data, settings)
   --nothing???
end

return plugin
